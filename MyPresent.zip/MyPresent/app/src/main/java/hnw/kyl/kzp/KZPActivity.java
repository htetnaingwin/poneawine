package hnw.kyl.kzp;

import android.animation.Animator;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;
import android.app.*;
import android.widget.*;
import android.view.*;
import android.view.animation.*;
import android.widget.AdapterView.*;
import android.content.*;

public class KZPActivity extends Activity {

    public LinearLayout illo;
	public TextView tv;
	private LinearLayout lo_1;
	
	ListView lv;
	String[] strs={"Ma Ma","Ko","A Yannn","Chit","Tae","Maung","Htar","Wa","Ra","Chit","Nay","Mal","Daw","Khine","Zon","Phyo","😂😂"};
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kzp);
		lv=findViewById(R.id.lv);
        lo_1 = findViewById(R.id.lo_1);
        lo_1.post(new Runnable() {
				@Override
				public void run() {
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
						int x = getIntent().getIntExtra("x", 0);
						int y = getIntent().getIntExtra("y", 0);
						Animator animator = createRevealAnimator(false, x+200, y+500);
						animator.start();
					}
                    lo_1.setVisibility(View.VISIBLE);

				}
			});

       /* lo_1.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
						Animator animator = createRevealAnimator(true, (int) event.getX(), (int) event.getY());
						animator.start();
					} else {
						finish();
					}
					return false;
				}
			});*/
			lv.setAdapter(new HNWAdapter());
			
		lv.setOnItemClickListener(new OnItemClickListener(){

				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					switch(p3){
						case 0:
							clickedItems();
							break;
					}
					
				}
				
				
			});
    }



    private Animator createRevealAnimator(boolean reversed, int x, int y) {
        float hypot = (float) Math.hypot(lo_1.getHeight(), lo_1.getWidth());
        float startRadius = reversed ? hypot : 0;
        float endRadius = reversed ? 0 : hypot;

        Animator animator = ViewAnimationUtils.createCircularReveal(
			lo_1, x, y,
			startRadius,
			endRadius);
        animator.setDuration(800);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        if (reversed)
            animator.addListener(animatorListener);
        return animator;
    }

    private Animator.AnimatorListener animatorListener = new Animator.AnimatorListener() {
        @Override
        public void onAnimationStart(Animator animation) {
        }

        @Override
        public void onAnimationEnd(Animator animation) {
            lo_1.setVisibility(View.INVISIBLE);
            finish();
        }

        @Override
        public void onAnimationCancel(Animator animation) {
        }

        @Override
        public void onAnimationRepeat(Animator animation) {
        }
    };

	@Override
	public void onBackPressed()
	{
		back();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId()){
			case android.R.id.home:
				back();
				break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void back(){
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Animator animator = createRevealAnimator(true, 270, 400);
			animator.start();
		} else {
			finish();
		}
	}
	private class HNWAdapter extends BaseAdapter
	{

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return strs.length;
		}

		@Override
		public Object getItem(int p1)
		{
			// TODO: Implement this method
			return null;
		}

		@Override
		public long getItemId(int p1)
		{
			// TODO: Implement this method
			return 0;
		}

		@Override
		public View getView(int p1, View p2, ViewGroup p3)
		{

			View myView=getLayoutInflater().inflate(R.layout.item_view,null);
			illo=myView.findViewById(R.id.itemviewLinearLayout1);
			tv=myView.findViewById(R.id.itemviewTextView1);

			LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(KZPActivity.this,getResources().getIdentifier("layout_animation_from_right","anim",getPackageName()));
			illo.setLayoutAnimation(animation);
			//your_adapter.notifyDataSetChanged();
			illo.scheduleLayoutAnimation();  


			tv.setText(strs[p1]);
			return myView;
		}


	}
	public void clickedItems(){
		AlertDialog.Builder alert=new AlertDialog.Builder(this);
		View myView=getLayoutInflater().inflate(R.layout.textview,null);
		alert.setView(myView);
		alert.show();
	}
	
}
