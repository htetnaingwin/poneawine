package hnw.kyl.kzp;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.view.animation.*;
import android.content.*;
public class MainActivity extends Activity
{
	CircleImageView im1;
	WebView wv;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		im1=findViewById(R.id.image_1);
		wv=findViewById(R.id.wv);
		wv.setVerticalScrollBarEnabled(false);
		wv.loadUrl("file:///android_asset/banner_animation.html");
		setRotateAnimation(im1);
		im1.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					Intent i = new Intent(MainActivity.this, KZPActivity.class);
					i.putExtra("x", (int)event.getX());
					i.putExtra("y", (int)event.getY());
					startActivity(i);
					return false;
				}
			});
	}
	public void setRotateAnimation(View view){
		Animation rotation = AnimationUtils.loadAnimation(this, R.anim.rotate);
		rotation.setRepeatCount(Animation.INFINITE);
		view.startAnimation(rotation);
	}
	}
